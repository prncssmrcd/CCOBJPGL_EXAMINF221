package Locations;

import Tourists.Tourist;

public interface Locations {

    int airFare = 1000;

    void accept(Tourist tourist);
}