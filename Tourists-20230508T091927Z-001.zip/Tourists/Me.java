package Tourists;


import Locations.*;

public class Me implements Tourist {

    static int budget = 1000;
    

    public void visit() {
        System.out.print("Enjoying my stay");
    }

    public void visit(Boracay boracay) {
        System.out.println("ang budget ko ay " + getBudget());

        if ( budget > boracay.airFare  ){
            System.out.println("Boracay Trip" );
            budget -= boracay.airFare;
            
        }else{
            System.out.println("insufficient Money");
        }

      checkBudget();
        
    }

    public void visit(tagaytay tagaytay) {

        if(budget >tagaytay.airFare){
            System.out.println("Tagaytay Trip");
            budget -= tagaytay.airFare;
        }else{
            System.out.println("insufficient Money");
        }

        checkBudget();
    }
    public void visit(LaUnion LaUnion) {
        if(budget >LaUnion.airFare){
            System.out.println("Launion naman nicee");
            budget -= LaUnion.airFare;
        }else{
            System.out.println("kulang na budget");
        }

        checkBudget();
    }

    public void visit(Palawan palawan) {
        if(budget >palawan.airFare){
            System.out.println("Tara palawan naman next");
            budget -= palawan.airFare;
        }else{
            System.out.println("wala na pera");
        }

        checkBudget();
    }

    public void visit(Banaue Banaue) {
        if(budget >Banaue.airFare){
            System.out.println("tara Banauee!!");
            budget -= Banaue.airFare;
        }else{
            System.out.println("ubos na money");
        }

        checkBudget();
    }

    public void visit(Vigan vigan) {
        if(budget >vigan.airFare){
            System.out.println("VIGAN NAMAN ");
            budget -= vigan.airFare;
        }else{
            System.out.println("umay naman ubos na pera");
        }

        checkBudget();
    }

    public void checkBudget() {
        System.out.println("my money is " + budget);
    }

    public static int getBudget() {
        return budget;
    }


}