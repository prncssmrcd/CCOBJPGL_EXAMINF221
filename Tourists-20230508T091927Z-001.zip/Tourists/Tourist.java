package Tourists;

import Locations.Boracay;
import Locations.Locations;
import Locations.tagaytay;
import Locations.LaUnion;
import Locations.Palawan;
import Locations.Banaue;
import Locations.Vigan;

public interface Tourist {

    int budget = 1000;

    void visit();

    void visit(Boracay boracay);

    void visit(tagaytay tagaytay);
    
    void visit(LaUnion LaUnion);

    void visit(Palawan palawan);

    void visit(Banaue Banaue);

    void visit(Vigan vigan);

    default void visit(Locations locations) {
        System.out.println("Arrived on a location");
    };

    void checkBudget();
}